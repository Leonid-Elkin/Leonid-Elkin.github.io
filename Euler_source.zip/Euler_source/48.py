sum = 0

for number in range (1,1_001):

    sum += number ** number

print(sum)