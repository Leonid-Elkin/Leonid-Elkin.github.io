check=0
number=3000000
check2=0
while check==0:
    number=number+1
    if number%20==0 and number%19==0 and number%18==0 and number%17==0 and number%16==0 and number % 15==0 and number %14==0 and number%13==0 and number%12==0 and number%11==0:
        check=1
print(number)
            