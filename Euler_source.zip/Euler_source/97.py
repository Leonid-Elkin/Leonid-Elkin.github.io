

num1 = int(str(16**2500)[-10:])

product = (num1**783) * (2**457)

strg = str(28433 * product + 1)

print(strg[-10:])

