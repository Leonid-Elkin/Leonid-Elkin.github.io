from itertools import permutations

coins = []

    