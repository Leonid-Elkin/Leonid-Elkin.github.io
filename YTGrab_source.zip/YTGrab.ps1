# YTGrab - a small WPF front-end for yt-dlp
# Launch via "YT Grab.bat" (needs -STA). Run with -SelfTest to validate without showing the UI.
param([switch]$SelfTest)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.Windows.Forms

# ---------------------------------------------------------------- tool lookup
function Find-Exe {
    param([string]$Name, [string[]]$Globs)
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    foreach ($g in $Globs) {
        $hit = Get-ChildItem -Path $g -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}

$pkgRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'
$script:YtDlp  = Find-Exe 'yt-dlp' @("$pkgRoot\yt-dlp.yt-dlp_*\yt-dlp.exe")
$script:Ffmpeg = Find-Exe 'ffmpeg' @("$pkgRoot\yt-dlp.FFmpeg_*\*\bin\ffmpeg.exe")
$script:Deno   = Find-Exe 'deno'   @("$pkgRoot\DenoLand.Deno_*\deno.exe")

# ---------------------------------------------------------------------- UI
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="YT Grab" Width="720" Height="640" MinWidth="600" MinHeight="520"
        WindowStartupLocation="CenterScreen" Background="#F4F4F8">
  <Window.Resources>
    <Style TargetType="Label">
      <Setter Property="Foreground" Value="#33334A"/>
      <Setter Property="Padding" Value="0,0,0,2"/>
      <Setter Property="FontSize" Value="12"/>
    </Style>
    <Style TargetType="TextBox">
      <Setter Property="Padding" Value="6,5"/>
      <Setter Property="BorderBrush" Value="#C9C9D6"/>
      <Setter Property="Background" Value="White"/>
      <Setter Property="FontSize" Value="13"/>
    </Style>
    <Style TargetType="Button">
      <Setter Property="Padding" Value="16,7"/>
      <Setter Property="FontSize" Value="13"/>
    </Style>
    <Style TargetType="ComboBox">
      <Setter Property="Padding" Value="6,5"/>
      <Setter Property="FontSize" Value="13"/>
    </Style>
  </Window.Resources>
  <TabControl Margin="12" Background="#F4F4F8" BorderBrush="#C9C9D6">
  <TabItem Header="  Download  " FontSize="13">
  <Grid Margin="10">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
    </Grid.RowDefinitions>

    <StackPanel Grid.Row="0" Orientation="Horizontal" Margin="0,0,0,12">
      <TextBlock Text="YT Grab" FontSize="22" FontWeight="Bold" Foreground="#C4302B"/>
      <TextBlock Text="video and playlist downloader" FontSize="13" Foreground="#8A8AA0"
                 VerticalAlignment="Bottom" Margin="10,0,0,3"/>
    </StackPanel>

    <StackPanel Grid.Row="1" Margin="0,0,0,10">
      <Label Content="Video or playlist URL"/>
      <TextBox x:Name="TxtUrl"/>
    </StackPanel>

    <Grid Grid.Row="2" Margin="0,0,0,10">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="140"/>
        <ColumnDefinition Width="150"/>
        <ColumnDefinition Width="130"/>
        <ColumnDefinition Width="110"/>
        <ColumnDefinition Width="*"/>
      </Grid.ColumnDefinitions>
      <StackPanel Grid.Column="0" Margin="0,0,10,0">
        <Label Content="Format"/>
        <ComboBox x:Name="CmbFormat"/>
      </StackPanel>
      <StackPanel Grid.Column="1" Margin="0,0,10,0">
        <Label Content="Quality"/>
        <ComboBox x:Name="CmbQuality"/>
      </StackPanel>
      <StackPanel Grid.Column="2" Margin="0,0,10,0">
        <Label Content="Playlist"/>
        <ComboBox x:Name="CmbRange"/>
      </StackPanel>
      <StackPanel Grid.Column="3" Margin="0,0,10,0">
        <Label x:Name="LblItems" Content="How many"/>
        <TextBox x:Name="TxtItems"/>
      </StackPanel>
      <CheckBox x:Name="ChkMerge" Grid.Column="4" Content="Merge into one file"
                VerticalAlignment="Bottom" Margin="0,0,0,7" Foreground="#33334A"/>
    </Grid>

    <Grid Grid.Row="3" Margin="0,0,0,12">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="*"/>
        <ColumnDefinition Width="Auto"/>
      </Grid.ColumnDefinitions>
      <StackPanel Grid.Column="0" Margin="0,0,10,0">
        <Label Content="Save to"/>
        <TextBox x:Name="TxtDest"/>
      </StackPanel>
      <Button x:Name="BtnBrowse" Grid.Column="1" Content="Browse..." VerticalAlignment="Bottom"/>
    </Grid>

    <StackPanel Grid.Row="4" Orientation="Horizontal" Margin="0,0,0,12">
      <Button x:Name="BtnStart" Content="Download" Background="#C4302B" Foreground="White"
              FontWeight="SemiBold" BorderBrush="#A02622" MinWidth="120"/>
      <Button x:Name="BtnCancel" Content="Cancel" Margin="10,0,0,0" IsEnabled="False"/>
      <Button x:Name="BtnOpen" Content="Open folder" Margin="10,0,0,0"/>
    </StackPanel>

    <StackPanel Grid.Row="5" Margin="0,0,0,10">
      <ProgressBar x:Name="Bar" Height="16" Minimum="0" Maximum="100"/>
      <TextBlock x:Name="LblStatus" Text="Ready" Foreground="#55556E" Margin="0,5,0,0" FontSize="12"/>
    </StackPanel>

    <TextBox x:Name="TxtLog" Grid.Row="6" IsReadOnly="True" FontFamily="Consolas" FontSize="11"
             Background="#1E1E2A" Foreground="#C8C8D8" BorderBrush="#C9C9D6"
             VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"
             TextWrapping="NoWrap" AcceptsReturn="True"/>
  </Grid>
  </TabItem>

  <TabItem Header="  Mic Player  " FontSize="13">
  <Grid Margin="10">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
    </Grid.RowDefinitions>

    <StackPanel Grid.Row="0" Margin="0,0,0,10">
      <TextBlock Text="Play songs through your microphone" FontSize="18" FontWeight="Bold" Foreground="#C4302B"/>
      <TextBlock Text="Plays the list into a virtual mic (VB-CABLE) so people in Discord / games hear the music instead of you. Your real mic is muted while playing. Songs advance automatically."
                 FontSize="12" Foreground="#8A8AA0" TextWrapping="Wrap" Margin="0,3,0,0"/>
    </StackPanel>

    <Border x:Name="PnlSetup" Grid.Row="1" Background="#FFF4E0" BorderBrush="#E0B860" BorderThickness="1"
            CornerRadius="4" Padding="10" Margin="0,0,0,10">
      <StackPanel>
        <TextBlock FontSize="12" Foreground="#5A4A20" TextWrapping="Wrap"
                   Text="VB-CABLE (free virtual audio cable) is not installed. It is needed to send audio into a microphone. Click Install, approve the admin prompt, then restart YT Grab. Afterwards set your app's microphone (Discord: Settings > Voice > Input Device) to 'CABLE Output'."/>
        <Button x:Name="BtnInstallCable" Content="Install VB-CABLE..." HorizontalAlignment="Left" Margin="0,8,0,0"/>
      </StackPanel>
    </Border>

    <Grid Grid.Row="2" Margin="0,0,0,10">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="*"/>
        <ColumnDefinition Width="Auto"/>
        <ColumnDefinition Width="Auto"/>
      </Grid.ColumnDefinitions>
      <StackPanel Grid.Column="0" Margin="0,0,10,0">
        <Label Content="Song folder"/>
        <TextBox x:Name="TxtPlDir"/>
      </StackPanel>
      <Button x:Name="BtnPlBrowse" Grid.Column="1" Content="Browse..." VerticalAlignment="Bottom" Margin="0,0,6,0"/>
      <Button x:Name="BtnPlRefresh" Grid.Column="2" Content="Refresh" VerticalAlignment="Bottom"/>
    </Grid>

    <Grid Grid.Row="3" Margin="0,0,0,10">
      <Grid.ColumnDefinitions>
        <ColumnDefinition Width="*"/>
        <ColumnDefinition Width="Auto"/>
      </Grid.ColumnDefinitions>
      <StackPanel Grid.Column="0" Margin="0,0,10,0">
        <Label Content="Play into (pick 'CABLE Input' - that is the virtual mic)"/>
        <ComboBox x:Name="CmbMicOut"/>
      </StackPanel>
      <StackPanel Grid.Column="1" VerticalAlignment="Bottom" Margin="0,0,0,4">
        <CheckBox x:Name="ChkMuteMic" Content="Mute my real mic while playing" IsChecked="True" Foreground="#33334A"/>
        <CheckBox x:Name="ChkAlsoLocal" Content="Also play on my speakers/headphones" IsChecked="True" Foreground="#33334A" Margin="0,4,0,0"/>
      </StackPanel>
    </Grid>

    <StackPanel Grid.Row="4" Orientation="Horizontal" Margin="0,0,0,8">
      <Button x:Name="BtnPlPrev" Content="|&lt;" MinWidth="44" Padding="8,7"/>
      <Button x:Name="BtnPlPlay" Content="Play" Background="#C4302B" Foreground="White" FontWeight="SemiBold"
              BorderBrush="#A02622" MinWidth="90" Margin="6,0,0,0"/>
      <Button x:Name="BtnPlPause" Content="Pause" MinWidth="70" Margin="6,0,0,0" IsEnabled="False"/>
      <Button x:Name="BtnPlStop" Content="Stop" MinWidth="70" Margin="6,0,0,0" IsEnabled="False"/>
      <Button x:Name="BtnPlNext" Content="&gt;|" MinWidth="44" Padding="8,7" Margin="6,0,0,0"/>
      <CheckBox x:Name="ChkLoop" Content="Loop list" VerticalAlignment="Center" Margin="16,0,0,0" Foreground="#33334A"/>
      <TextBlock Text="Volume" VerticalAlignment="Center" Margin="16,0,6,0" Foreground="#33334A" FontSize="12"/>
      <Slider x:Name="SldVol" Width="120" Minimum="0" Maximum="1" Value="0.8" VerticalAlignment="Center"/>
    </StackPanel>

    <StackPanel Grid.Row="5" Margin="0,0,0,8">
      <ProgressBar x:Name="BarPl" Height="10" Minimum="0" Maximum="1000"/>
      <TextBlock x:Name="LblNow" Text="Nothing playing" Foreground="#55556E" Margin="0,5,0,0" FontSize="12"/>
    </StackPanel>

    <ListBox x:Name="LstSongs" Grid.Row="6" FontSize="13" BorderBrush="#C9C9D6"/>
  </Grid>
  </TabItem>
  </TabControl>
</Window>
'@

$Window = [Windows.Markup.XamlReader]::Parse($xaml)
foreach ($n in 'TxtUrl','CmbFormat','CmbQuality','CmbRange','LblItems','TxtItems','ChkMerge','TxtDest',
               'BtnBrowse','BtnStart','BtnCancel','BtnOpen','Bar','LblStatus','TxtLog',
               'PnlSetup','BtnInstallCable','TxtPlDir','BtnPlBrowse','BtnPlRefresh','CmbMicOut',
               'ChkMuteMic','ChkAlsoLocal','BtnPlPrev','BtnPlPlay','BtnPlPause','BtnPlStop','BtnPlNext',
               'ChkLoop','SldVol','BarPl','LblNow','LstSongs') {
    Set-Variable -Name $n -Value $Window.FindName($n) -Scope Script
}

# ------------------------------------------------------------ NAudio (mic player)
$script:NAudioOk = $false
try {
    $libDir = Join-Path $PSScriptRoot 'lib'
    foreach ($d in 'NAudio.Core', 'NAudio.WinMM', 'NAudio.Wasapi') { Add-Type -Path (Join-Path $libDir "$d.dll") }
    $script:NAudioOk = $true
} catch { $script:NAudioErr = $_.Exception.Message }

# ------------------------------------------------------------------- state
$script:Proc = $null          # running yt-dlp/ffmpeg process
$script:Phase = 'idle'        # idle | download | merge
$script:Tmp = $null           # per-job temp dir
$script:Dest = $null
$script:OutLog = $null; $script:ErrLog = $null
$script:OutOff = 0;     $script:ErrOff = 0
$script:Cur = 0; $script:Total = 0
$script:MergeWanted = $false
$script:MergedPath = $null; $script:MergedName = $null

$script:Timer = New-Object Windows.Threading.DispatcherTimer
$script:Timer.Interval = [TimeSpan]::FromMilliseconds(300)

# ----------------------------------------------------------------- helpers
function Append-Log([string]$text) {
    if (-not $text) { return }
    if ($TxtLog.Text.Length -gt 400000) { $TxtLog.Text = $TxtLog.Text.Substring(200000) }
    $TxtLog.AppendText($text)
    if (-not $text.EndsWith("`n")) { $TxtLog.AppendText("`r`n") }
    $TxtLog.ScrollToEnd()
}

function Set-Status([string]$s) { $LblStatus.Text = $s }

function Sanitize-Name([string]$s) {
    $s = ($s -replace '[\\/:*?"<>|]', '_').Trim()
    if ($s.Length -gt 150) { $s = $s.Substring(0, 150) }
    if (-not $s) { $s = 'Playlist' }
    return $s
}

function Join-CmdArgs([string[]]$parts) {
    ($parts | ForEach-Object {
        if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ }
    }) -join ' '
}

function Read-NewText([string]$path, [ref]$offset) {
    if (-not $path -or -not (Test-Path $path)) { return '' }
    try {
        $fs = [IO.File]::Open($path, 'Open', 'Read', 'ReadWrite')
        try {
            [void]$fs.Seek($offset.Value, 'Begin')
            $sr = New-Object IO.StreamReader($fs)
            $t = $sr.ReadToEnd()
            $offset.Value = $fs.Position
            return $t
        } finally { $fs.Dispose() }
    } catch { return '' }
}

function Update-QualityList {
    if (-not $CmbQuality) { return }
    $CmbQuality.Items.Clear()
    if ($CmbFormat.SelectedIndex -eq 0) {   # audio
        foreach ($q in '320 kbps (best)', '192 kbps (recommended)', '128 kbps (small)') {
            [void]$CmbQuality.Items.Add($q)
        }
        $CmbQuality.SelectedIndex = 1
        $ChkMerge.IsEnabled = $true
    } else {                                # video
        foreach ($q in 'Best available', '1080p', '720p', '480p') { [void]$CmbQuality.Items.Add($q) }
        $CmbQuality.SelectedIndex = 0
        $ChkMerge.IsChecked = $false
        $ChkMerge.IsEnabled = $false        # merging only supported for audio
    }
}

# Playlist range selector: All / First N / Custom -> yt-dlp --playlist-items value
function Get-PlaylistItems {
    $txt = $TxtItems.Text.Trim()
    switch ($CmbRange.SelectedIndex) {
        1 { $n = 0; if ([int]::TryParse($txt, [ref]$n) -and $n -gt 0) { return "1-$n" } else { return $null } }
        2 { return $txt }
        default { return $null }
    }
}

function Update-RangeUi {
    switch ($CmbRange.SelectedIndex) {
        1 { $LblItems.Content = 'How many';        $TxtItems.IsEnabled = $true;  if ($TxtItems.Text -notmatch '^\d+$') { $TxtItems.Text = '10' } }
        2 { $LblItems.Content = 'Items (1-25,30)';  $TxtItems.IsEnabled = $true }
        default { $LblItems.Content = 'How many'; $TxtItems.IsEnabled = $false; $TxtItems.Text = '' }
    }
}

# Turn any YouTube link that carries a real playlist id into the canonical
# playlist URL so yt-dlp downloads that playlist from item 1, not a Mix/Radio
# built around the current video. Returns @{ Url; Kind } with Kind =
# 'playlist' | 'mix' | 'video' | 'other'.
function Resolve-YouTubeUrl([string]$url) {
    $u = $url.Trim()
    if ($u -notmatch 'youtu\.?be') { return @{ Url = $u; Kind = 'other' } }
    $list = $null
    if ($u -match '[?&]list=([A-Za-z0-9_-]+)') { $list = $Matches[1] }
    if ($list) {
        if ($list -like 'RD*') {
            # Mix/Radio: keep as-is (needs the v= seed), caller warns
            return @{ Url = $u; Kind = 'mix' }
        }
        return @{ Url = "https://www.youtube.com/playlist?list=$list"; Kind = 'playlist' }
    }
    if ($u -match '(?:v=|youtu\.be/|shorts/)([A-Za-z0-9_-]{11})') {
        return @{ Url = "https://www.youtube.com/watch?v=$($Matches[1])"; Kind = 'video' }
    }
    return @{ Url = $u; Kind = 'other' }
}

# --------------------------------------------------------------- job logic
function Build-DownloadArgs {
    $url = (Resolve-YouTubeUrl $TxtUrl.Text).Url
    $isAudio = ($CmbFormat.SelectedIndex -eq 0)
    $q = [string]$CmbQuality.SelectedItem
    $items = Get-PlaylistItems

    $a = New-Object System.Collections.Generic.List[string]
    foreach ($x in '--newline', '--ignore-errors', '--windows-filenames', '--yes-playlist') { $a.Add($x) }
    $a.Add('--ffmpeg-location'); $a.Add((Split-Path $script:Ffmpeg))
    if ($script:Deno) { $a.Add('--js-runtimes'); $a.Add("deno:$($script:Deno)") }
    if ($items) { $a.Add('--playlist-items'); $a.Add($items) }

    if ($isAudio) {
        $a.Add('-x'); $a.Add('--audio-format'); $a.Add('mp3')
        $kbps = ($q -replace '\D', '')
        $a.Add('--audio-quality'); $a.Add("${kbps}K")
        if (-not $script:MergeWanted) {
            $a.Add('--embed-thumbnail'); $a.Add('--embed-metadata')
            $a.Add('--convert-thumbnails'); $a.Add('jpg')
        }
    } else {
        $h = ($q -replace '\D', '')
        if ($h) { $fmt = "bestvideo[ext=mp4][height<=$h]+bestaudio[ext=m4a]/best[ext=mp4]/best" }
        else    { $fmt = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best' }
        $a.Add('-f'); $a.Add($fmt)
        $a.Add('--merge-output-format'); $a.Add('mp4')
        $a.Add('--embed-metadata')
    }

    if ($script:MergeWanted) {
        $a.Add('-o'); $a.Add("$($script:Tmp)\%(playlist_index)03d.%(ext)s")
        $a.Add('--print-to-file'); $a.Add('%(playlist_index)03d - %(title)s'); $a.Add("$($script:Tmp)\tracklist.txt")
        $a.Add('--print-to-file'); $a.Add('%(playlist_title)s'); $a.Add("$($script:Tmp)\ptitle.txt")
    } else {
        $a.Add('-o'); $a.Add("$($script:Dest)\%(title)s.%(ext)s")
    }
    $a.Add($url)
    return ,$a.ToArray()
}

function Set-Busy([bool]$busy) {
    $BtnStart.IsEnabled = -not $busy
    $BtnCancel.IsEnabled = $busy
    foreach ($c in $TxtUrl, $CmbFormat, $CmbQuality, $CmbRange, $TxtDest, $BtnBrowse) { $c.IsEnabled = -not $busy }
    $TxtItems.IsEnabled = (-not $busy) -and ($CmbRange.SelectedIndex -gt 0)
    $ChkMerge.IsEnabled = (-not $busy) -and ($CmbFormat.SelectedIndex -eq 0)
}

function Start-Download {
    $url = $TxtUrl.Text.Trim()
    if (-not $url) { Set-Status 'Enter a URL first.'; return }
    if (-not $script:YtDlp -or -not $script:Ffmpeg) {
        Set-Status 'yt-dlp / ffmpeg not found - see log.'
        Append-Log 'Missing tools. Install with:  winget install yt-dlp.yt-dlp'
        return
    }
    $script:Dest = $TxtDest.Text.Trim()
    if (-not $script:Dest) { $script:Dest = Join-Path $env:USERPROFILE 'Downloads' }
    New-Item -ItemType Directory -Force $script:Dest | Out-Null
    $script:MergeWanted = [bool]$ChkMerge.IsChecked
    $script:JobStart = Get-Date

    $r = Resolve-YouTubeUrl $url
    switch ($r.Kind) {
        'playlist' { Append-Log "Playlist detected - downloading the full playlist: $($r.Url)" }
        'video'    { Append-Log "Single video: $($r.Url)" }
        'mix'      { Append-Log "WARNING: this is a YouTube Mix/Radio (list=RD...), i.e. auto-generated related songs, not a real playlist. Open the actual playlist page and paste that URL if that's not what you want." }
    }

    $script:Tmp = Join-Path $env:TEMP ('YTGrab\job_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    New-Item -ItemType Directory -Force $script:Tmp | Out-Null
    $script:OutLog = Join-Path $script:Tmp 'stdout.log'
    $script:ErrLog = Join-Path $script:Tmp 'stderr.log'
    $script:OutOff = 0; $script:ErrOff = 0
    $script:Cur = 0; $script:Total = 0
    $script:MergedPath = $null

    $argStr = Join-CmdArgs (Build-DownloadArgs)
    Append-Log "> yt-dlp $argStr"
    $script:Proc = Start-Process -FilePath $script:YtDlp -ArgumentList $argStr `
        -RedirectStandardOutput $script:OutLog -RedirectStandardError $script:ErrLog `
        -WindowStyle Hidden -PassThru
    $script:Phase = 'download'
    $Bar.IsIndeterminate = $false; $Bar.Value = 0
    Set-Status 'Starting...'
    Set-Busy $true
    $script:Timer.Start()
}

function Start-Merge {
    $mp3s = @(Get-ChildItem $script:Tmp -Filter *.mp3 -ErrorAction SilentlyContinue | Sort-Object Name)
    if ($mp3s.Count -eq 0) {
        Append-Log 'Nothing was downloaded - nothing to merge.'
        Finish-Job 1
        return
    }
    $title = 'Playlist'
    $pt = Join-Path $script:Tmp 'ptitle.txt'
    if (Test-Path $pt) {
        $t = Get-Content $pt -TotalCount 1 -ErrorAction SilentlyContinue
        if ($t -and $t -ne 'NA') { $title = $t }
    }
    $script:MergedName = Sanitize-Name "$title ($($mp3s.Count) tracks)"
    $script:MergedPath = Join-Path $script:Dest "$($script:MergedName).mp3"

    if ($mp3s.Count -eq 1) {
        Copy-Item $mp3s[0].FullName $script:MergedPath -Force
        Finish-Job 0
        return
    }

    $concat = Join-Path $script:Tmp 'concat.txt'
    $mp3s | ForEach-Object {
        "file '" + (($_.FullName -replace '\\', '/') -replace "'", "'\''") + "'"
    } | Out-File $concat -Encoding ascii

    $script:OutLog = Join-Path $script:Tmp 'ffmpeg_out.log'
    $script:ErrLog = Join-Path $script:Tmp 'ffmpeg_err.log'
    $script:OutOff = 0; $script:ErrOff = 0

    $argStr = Join-CmdArgs @('-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0',
                             '-i', $concat, '-c', 'copy', $script:MergedPath)
    Append-Log "> ffmpeg $argStr"
    $script:Proc = Start-Process -FilePath $script:Ffmpeg -ArgumentList $argStr `
        -RedirectStandardOutput $script:OutLog -RedirectStandardError $script:ErrLog `
        -WindowStyle Hidden -PassThru
    $script:Phase = 'merge'
    $Bar.IsIndeterminate = $true
    Set-Status "Merging $($mp3s.Count) tracks into one file..."
}

function Finish-Job([int]$code) {
    $script:Timer.Stop()
    $script:Proc = $null
    $Bar.IsIndeterminate = $false

    if ($script:MergeWanted -and $script:MergedPath -and (Test-Path $script:MergedPath)) {
        $tl = Join-Path $script:Tmp 'tracklist.txt'
        if (Test-Path $tl) {
            Copy-Item $tl (Join-Path $script:Dest "$($script:MergedName) - tracklist.txt") -Force
        }
        $mb = [math]::Round((Get-Item $script:MergedPath).Length / 1MB, 1)
        Append-Log "Merged file: $($script:MergedPath) ($mb MB)"
    }
    if ($script:Tmp -and (Test-Path $script:Tmp)) {
        Remove-Item $script:Tmp -Recurse -Force -ErrorAction SilentlyContinue
    }
    # thumbnails yt-dlp failed to embed get left next to the media file
    if ($script:Dest -and (Test-Path $script:Dest)) {
        $stray = Get-ChildItem $script:Dest -File -Include '*.webp','*.jpg','*.png' -Recurse:$false |
                 Where-Object { $_.LastWriteTime -ge $script:JobStart }
        if ($stray) {
            $stray | Remove-Item -Force -ErrorAction SilentlyContinue
            Append-Log "Removed $($stray.Count) leftover thumbnail file(s)."
        }
    }

    if ($code -eq 0) {
        $Bar.Value = 100
        Set-Status "Done - saved to $($script:Dest)"
        Append-Log 'Done.'
    } else {
        Set-Status "Finished with errors (exit code $code) - check the log."
    }
    $script:Phase = 'idle'
    Set-Busy $false
}

function Stop-Download {
    if ($script:Proc -and -not $script:Proc.HasExited) {
        Start-Process -FilePath 'taskkill' -ArgumentList "/PID $($script:Proc.Id) /T /F" `
            -WindowStyle Hidden -Wait
    }
    $script:Timer.Stop()
    $script:Proc = $null
    $script:Phase = 'idle'
    $Bar.IsIndeterminate = $false
    Set-Status 'Cancelled.'
    Append-Log 'Cancelled by user.'
    Set-Busy $false
}

function Parse-Progress([string]$text) {
    foreach ($m in [regex]::Matches($text, '\[download\] Downloading item (\d+) of (\d+)')) {
        $script:Cur = [int]$m.Groups[1].Value
        $script:Total = [int]$m.Groups[2].Value
    }
    $pm = [regex]::Matches($text, '\[download\]\s+([0-9.]+)%')
    $pct = -1
    if ($pm.Count -gt 0) { $pct = [double]$pm[$pm.Count - 1].Groups[1].Value }
    if ($pct -lt 0) { return }
    if ($script:Total -gt 0) {
        $overall = (($script:Cur - 1) + $pct / 100) / $script:Total * 100
        $Bar.Value = [math]::Min(100, [math]::Max(0, $overall))
        Set-Status ("Downloading {0} of {1}  -  {2:N0}%" -f $script:Cur, $script:Total, $pct)
    } else {
        $Bar.Value = $pct
        Set-Status ("Downloading  -  {0:N0}%" -f $pct)
    }
}

function On-Tick {
    $newOut = Read-NewText $script:OutLog ([ref]$script:OutOff)
    $newErr = Read-NewText $script:ErrLog ([ref]$script:ErrOff)
    if ($newOut) { Append-Log $newOut.TrimEnd(); Parse-Progress $newOut }
    if ($newErr) { Append-Log $newErr.TrimEnd() }

    if ($script:Proc -and $script:Proc.HasExited) {
        $newOut = Read-NewText $script:OutLog ([ref]$script:OutOff)   # final flush
        $newErr = Read-NewText $script:ErrLog ([ref]$script:ErrOff)
        if ($newOut) { Append-Log $newOut.TrimEnd() }
        if ($newErr) { Append-Log $newErr.TrimEnd() }
        $code = $script:Proc.ExitCode
        $script:Proc = $null
        if ($script:Phase -eq 'download' -and $script:MergeWanted -and $code -le 1) {
            # exit 1 with --ignore-errors just means some items failed; merge what we got
            Start-Merge
        } else {
            Finish-Job $code
        }
    }
}

# ------------------------------------------------------------- mic player
$script:PlFiles  = @()          # full paths, same order as LstSongs
$script:PlIndex  = -1
$script:PlOut    = $null        # WasapiOut -> virtual mic
$script:PlOutLoc = $null        # WasapiOut -> speakers (optional)
$script:PlReaders = @()
$script:PlVol    = $null        # VolumeSampleProvider(s)
$script:PlActive = $false       # true while a song is playing/paused (used for auto-advance)
$script:MutedMics = @()         # capture devices we muted, to restore later
$script:PlDevices = @()         # MMDevice list matching CmbMicOut

$script:PlTimer = New-Object Windows.Threading.DispatcherTimer
$script:PlTimer.Interval = [TimeSpan]::FromMilliseconds(250)

function Get-Enumerator { New-Object NAudio.CoreAudioApi.MMDeviceEnumerator }

function Refresh-OutputDevices {
    $CmbMicOut.Items.Clear(); $script:PlDevices = @()
    if (-not $script:NAudioOk) { [void]$CmbMicOut.Items.Add("NAudio failed to load: $($script:NAudioErr)"); return }
    $en = Get-Enumerator
    $devs = @($en.EnumerateAudioEndPoints([NAudio.CoreAudioApi.DataFlow]::Render, [NAudio.CoreAudioApi.DeviceState]::Active))
    $script:PlDevices = $devs
    $pick = 0
    for ($i = 0; $i -lt $devs.Count; $i++) {
        [void]$CmbMicOut.Items.Add($devs[$i].FriendlyName)
        if ($devs[$i].FriendlyName -match 'CABLE Input') { $pick = $i }
    }
    $hasCable = [bool]($devs | Where-Object { $_.FriendlyName -match 'CABLE Input' })
    $PnlSetup.Visibility = if ($hasCable) { 'Collapsed' } else { 'Visible' }
    if ($devs.Count) { $CmbMicOut.SelectedIndex = $pick }
}

function Refresh-SongList {
    $LstSongs.Items.Clear(); $script:PlFiles = @()
    $dir = $TxtPlDir.Text.Trim()
    if (-not $dir -or -not (Test-Path $dir)) { return }
    $files = Get-ChildItem $dir -File |
             Where-Object { $_.Extension -match '^\.(mp3|m4a|wav|flac|aac|wma|mp4)$' } |
             Sort-Object Name
    $script:PlFiles = @($files | ForEach-Object { $_.FullName })
    foreach ($f in $files) { [void]$LstSongs.Items.Add($f.BaseName) }
    $LblNow.Text = "$($files.Count) song(s) in list"
}

function Set-MicMuted([bool]$mute) {
    if (-not $script:NAudioOk) { return }
    try {
        $en = Get-Enumerator
        if ($mute) {
            $script:MutedMics = @()
            $caps = $en.EnumerateAudioEndPoints([NAudio.CoreAudioApi.DataFlow]::Capture, [NAudio.CoreAudioApi.DeviceState]::Active)
            foreach ($c in $caps) {
                if ($c.FriendlyName -match 'CABLE Output') { continue }   # that's the virtual mic itself
                if (-not $c.AudioEndpointVolume.Mute) {
                    $c.AudioEndpointVolume.Mute = $true
                    $script:MutedMics += $c
                }
            }
        } else {
            foreach ($c in $script:MutedMics) { try { $c.AudioEndpointVolume.Mute = $false } catch {} }
            $script:MutedMics = @()
        }
    } catch { $LblNow.Text = "Mic mute failed: $($_.Exception.Message)" }
}

function New-Output([object]$device, [string]$path) {
    $reader = New-Object NAudio.Wave.MediaFoundationReader($path)
    $sp  = [NAudio.Wave.WaveExtensionMethods]::ToSampleProvider($reader)   # extension method; PS can't call it as instance
    $vol = New-Object NAudio.Wave.SampleProviders.VolumeSampleProvider($sp)
    $vol.Volume = [single]$SldVol.Value
    $out = New-Object NAudio.Wave.WasapiOut($device, [NAudio.CoreAudioApi.AudioClientShareMode]::Shared, $true, 150)
    $out.Init([NAudio.Wave.WaveExtensionMethods]::ToWaveProvider($vol))
    $script:PlReaders += $reader
    $script:PlVol += $vol
    return $out
}

function Stop-Playback([bool]$keepMute = $false) {
    $script:PlTimer.Stop()
    $script:PlActive = $false
    foreach ($o in $script:PlOut, $script:PlOutLoc) { if ($o) { try { $o.Stop(); $o.Dispose() } catch {} } }
    foreach ($r in $script:PlReaders) { try { $r.Dispose() } catch {} }
    $script:PlOut = $null; $script:PlOutLoc = $null; $script:PlReaders = @(); $script:PlVol = @()
    if (-not $keepMute) { Set-MicMuted $false }
    $BtnPlPause.IsEnabled = $false; $BtnPlStop.IsEnabled = $false
    $BtnPlPause.Content = 'Pause'
    $BarPl.Value = 0
}

function Play-Index([int]$i) {
    if (-not $script:NAudioOk) { $LblNow.Text = "Player unavailable: $($script:NAudioErr)"; return }
    if ($script:PlFiles.Count -eq 0) { $LblNow.Text = 'No songs in the list - pick a folder with mp3s.'; return }
    if ($i -lt 0 -or $i -ge $script:PlFiles.Count) { Stop-Playback; $LblNow.Text = 'End of list.'; return }
    Stop-Playback -keepMute $true
    $dev = $script:PlDevices[$CmbMicOut.SelectedIndex]
    if (-not $dev) { $LblNow.Text = 'Pick an output device first.'; return }
    try {
        $script:PlIndex = $i
        $path = $script:PlFiles[$i]
        $script:PlOut = New-Output $dev $path
        if ($ChkAlsoLocal.IsChecked) {
            $spk = (Get-Enumerator).GetDefaultAudioEndpoint([NAudio.CoreAudioApi.DataFlow]::Render, [NAudio.CoreAudioApi.Role]::Multimedia)
            if ($spk.ID -ne $dev.ID) { $script:PlOutLoc = New-Output $spk $path }
        }
        if ($ChkMuteMic.IsChecked) { Set-MicMuted $true } else { Set-MicMuted $false }
        $script:PlOut.Play()
        if ($script:PlOutLoc) { $script:PlOutLoc.Play() }
        $script:PlActive = $true
        $LstSongs.SelectedIndex = $i; $LstSongs.ScrollIntoView($LstSongs.Items[$i])
        $BtnPlPause.IsEnabled = $true; $BtnPlStop.IsEnabled = $true
        $LblNow.Text = "Playing: $([IO.Path]::GetFileNameWithoutExtension($path))"
        $script:PlTimer.Start()
    } catch {
        $LblNow.Text = "Playback failed: $($_.Exception.Message)"
        Stop-Playback
    }
}

function On-PlTick {
    if (-not $script:PlActive -or -not $script:PlOut) { return }
    $r = $script:PlReaders[0]
    if ($r.TotalTime.TotalSeconds -gt 0) {
        $BarPl.Value = [math]::Min(1000, 1000 * $r.CurrentTime.TotalSeconds / $r.TotalTime.TotalSeconds)
        $name = [IO.Path]::GetFileNameWithoutExtension($script:PlFiles[$script:PlIndex])
        $state = if ($script:PlOut.PlaybackState -eq 'Paused') { 'Paused' } else { 'Playing' }
        $LblNow.Text = "{0}: {1}  [{2:mm\:ss} / {3:mm\:ss}]  ({4} of {5})" -f $state, $name, $r.CurrentTime, $r.TotalTime, ($script:PlIndex + 1), $script:PlFiles.Count
    }
    if ($script:PlOut.PlaybackState -eq 'Stopped') {
        $next = $script:PlIndex + 1
        if ($next -ge $script:PlFiles.Count -and $ChkLoop.IsChecked) { $next = 0 }
        Play-Index $next
    }
}

function Install-VbCable {
    $url = 'https://download.vb-audio.com/Download_CABLE/VBCABLE_Driver_Pack45.zip'
    $dir = Join-Path $env:TEMP 'YTGrab\vbcable'
    try {
        $LblNow.Text = 'Downloading VB-CABLE...'
        New-Item -ItemType Directory -Force $dir | Out-Null
        $zip = Join-Path $dir 'vbcable.zip'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest $url -OutFile $zip -UseBasicParsing
        Expand-Archive $zip $dir -Force
        $setup = Get-ChildItem $dir -Recurse -Filter 'VBCABLE_Setup_x64.exe' | Select-Object -First 1
        if (-not $setup) { throw 'installer not found in zip' }
        Start-Process $setup.FullName -Verb RunAs
        $LblNow.Text = "Installer launched - click 'Install Driver', then restart YT Grab."
    } catch {
        $LblNow.Text = "VB-CABLE install failed: $($_.Exception.Message). Get it manually from vb-audio.com/Cable"
    }
}

# ---------------------------------------------------------------- wire up
$CmbFormat.Items.Add('Audio (mp3)') | Out-Null
$CmbFormat.Items.Add('Video (mp4)') | Out-Null
$CmbFormat.Add_SelectionChanged({ Update-QualityList })
$CmbFormat.SelectedIndex = 0
foreach ($r in 'All items', 'First N items', 'Custom range') { [void]$CmbRange.Items.Add($r) }
$CmbRange.Add_SelectionChanged({ Update-RangeUi })
$CmbRange.SelectedIndex = 0
$TxtDest.Text = Join-Path $env:USERPROFILE 'Downloads'

$BtnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Choose the download folder'
    $dlg.SelectedPath = $TxtDest.Text
    if ($dlg.ShowDialog() -eq 'OK') { $TxtDest.Text = $dlg.SelectedPath }
})
$BtnStart.Add_Click({ Start-Download })
$BtnCancel.Add_Click({ Stop-Download })
$BtnOpen.Add_Click({
    $d = $TxtDest.Text.Trim()
    if ($d -and (Test-Path $d)) { Start-Process explorer.exe $d }
})
$script:Timer.Add_Tick({ On-Tick })
$Window.Add_Closing({
    if ($script:Proc -and -not $script:Proc.HasExited) { Stop-Download }
    Stop-Playback
})

# mic player wiring
$TxtPlDir.Text = $TxtDest.Text
Refresh-OutputDevices
Refresh-SongList
$BtnPlBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Folder with the songs to play'
    $dlg.SelectedPath = $TxtPlDir.Text
    if ($dlg.ShowDialog() -eq 'OK') { $TxtPlDir.Text = $dlg.SelectedPath; Refresh-SongList }
})
$BtnPlRefresh.Add_Click({ Refresh-OutputDevices; Refresh-SongList })
$BtnInstallCable.Add_Click({ Install-VbCable })
$BtnPlPlay.Add_Click({
    $i = $LstSongs.SelectedIndex
    if ($i -lt 0) { $i = 0 }
    Play-Index $i
})
$LstSongs.Add_MouseDoubleClick({ if ($LstSongs.SelectedIndex -ge 0) { Play-Index $LstSongs.SelectedIndex } })
$BtnPlPause.Add_Click({
    if (-not $script:PlOut) { return }
    if ($script:PlOut.PlaybackState -eq 'Paused') {
        $script:PlOut.Play(); if ($script:PlOutLoc) { $script:PlOutLoc.Play() }
        $BtnPlPause.Content = 'Pause'
    } else {
        $script:PlOut.Pause(); if ($script:PlOutLoc) { $script:PlOutLoc.Pause() }
        $BtnPlPause.Content = 'Resume'
    }
})
$BtnPlStop.Add_Click({ Stop-Playback; $LblNow.Text = 'Stopped - mic restored.' })
$BtnPlNext.Add_Click({ if ($script:PlFiles.Count) { Play-Index (($script:PlIndex + 1) % $script:PlFiles.Count) } })
$BtnPlPrev.Add_Click({ if ($script:PlFiles.Count) { Play-Index (($script:PlIndex - 1 + $script:PlFiles.Count) % $script:PlFiles.Count) } })
$SldVol.Add_ValueChanged({ foreach ($v in $script:PlVol) { $v.Volume = [single]$SldVol.Value } })
$script:PlTimer.Add_Tick({ On-PlTick })

if (-not $script:YtDlp)  { Append-Log 'WARNING: yt-dlp not found. Install:  winget install yt-dlp.yt-dlp' }
if (-not $script:Ffmpeg) { Append-Log 'WARNING: ffmpeg not found. Install:  winget install yt-dlp.FFmpeg' }
Append-Log "yt-dlp : $($script:YtDlp)"
Append-Log "ffmpeg : $($script:Ffmpeg)"
Append-Log "Tip: Mix/Radio playlists (list=RD...) are endless - set Playlist to 'First N items'."

# ---------------------------------------------------------------- self test
if ($SelfTest) {
    Write-Output "XAML   : OK ('$($Window.Title)')"
    Write-Output "yt-dlp : $($script:YtDlp)"
    Write-Output "ffmpeg : $($script:Ffmpeg)"
    Write-Output "deno   : $($script:Deno)"
    Write-Output "NAudio : $($script:NAudioOk) $($script:NAudioErr)"
    Write-Output "outputs: $($script:PlDevices.Count) ($($CmbMicOut.SelectedItem)); VB-CABLE panel: $($PnlSetup.Visibility)"
    Write-Output "songs  : $($script:PlFiles.Count) in $($TxtPlDir.Text)"
    $TxtUrl.Text = 'https://www.youtube.com/watch?v=SAMPLE'
    $script:Dest = $TxtDest.Text
    $script:MergeWanted = $false
    Write-Output ('args (plain) : ' + (Join-CmdArgs (Build-DownloadArgs)))
    $CmbRange.SelectedIndex = 1; $TxtItems.Text = '5'
    Write-Output ('args (first5): ' + (Join-CmdArgs (Build-DownloadArgs)))
    $CmbRange.SelectedIndex = 0
    foreach ($t in 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=PLabc_123&index=7',
                   'https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=RDdQw4w9WgXcQ&start_radio=1',
                   'https://youtu.be/dQw4w9WgXcQ?si=xyz',
                   'https://www.youtube.com/playlist?list=PLabc_123') {
        $r = Resolve-YouTubeUrl $t
        Write-Output "resolve [$($r.Kind)] $t -> $($r.Url)"
    }
    $script:MergeWanted = $true
    $script:Tmp = 'C:\TMP\job'
    Write-Output ('args (merge) : ' + (Join-CmdArgs (Build-DownloadArgs)))
    exit 0
}

[void]$Window.ShowDialog()
