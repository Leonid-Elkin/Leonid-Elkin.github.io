# YT Grab

A small Windows GUI for downloading YouTube videos and playlists via yt-dlp.
Pure PowerShell + WPF — nothing to install beyond yt-dlp/ffmpeg.

## Run

Double-click **`YT Grab.bat`** (right-click → Send to → Desktop to make a shortcut).

## Features

- **Audio (mp3)** at 128/192/320 kbps, with embedded metadata + thumbnail,
  or **Video (mp4)** at Best/1080p/720p/480p (h264 preferred for compatibility;
  YouTube only serves h264 up to ~1080p, so "Best" effectively caps there).
- **Playlists**: the **Playlist** dropdown picks *All items*, *First N items*
  (type how many in the box next to it) or *Custom range* (`1-25`, `3,7`, `10-`).
  Use First N for Mix/Radio playlists (`list=RD...`), which are endless
  (yt-dlp resolves them to hundreds of entries).
- **Merge into one file** (audio only): downloads the tracks, concatenates them
  into a single mp3 named after the playlist, and drops a matching
  `... - tracklist.txt` next to it.
- Progress bar (per-item and overall), live log, Cancel, folder picker.

## Mic Player tab

Plays your downloaded songs *into your microphone* so people on Discord /
in games hear the music instead of you. Songs auto-advance; your real mic is
muted while playing and restored on Stop.

Windows can't feed audio into a mic by itself, so this needs the free
**VB-CABLE** virtual audio cable. One-time setup:

1. Mic Player tab → **Install VB-CABLE...** (approve the admin prompt, click
   *Install Driver*, restart YT Grab). Or download it from vb-audio.com/Cable.
2. In the app you're talking in, set the **microphone / input device** to
   **`CABLE Output (VB-Audio Virtual Cable)`**.
3. In YT Grab, leave **Play into** on **`CABLE Input`** and press Play.

Tick *Also play on my speakers* to hear it yourself. Untick *Mute my real mic*
if you want to talk over the music (people will hear both). Set the other
app's mic back to your real one when you're done.

## Requirements

Installed via winget (already present on this machine):

```
winget install yt-dlp.yt-dlp    # pulls in ffmpeg + deno as dependencies
```

The app finds the executables on PATH or in the winget package folders
automatically. If YouTube starts returning **HTTP 403** on downloads, update
yt-dlp: `yt-dlp --update-to nightly`.

## Files

- `YTGrab.ps1` — the app (WPF UI, ~all the logic)
- `YT Grab.bat` — launcher (starts PowerShell in STA mode, hidden console)

Diagnostics: run `powershell -STA -File YTGrab.ps1 -SelfTest` to check tool
discovery and the generated yt-dlp command lines without opening the UI.
