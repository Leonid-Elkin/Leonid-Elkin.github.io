from MLP import MLP
import numpy as np

def loadMNIST():
    from tensorflow.keras.datasets import mnist
    print("loaded in")
    (trainingImages, trainingLabels), (testingImages, testingLabels) = mnist.load_data()

    trainingImages = trainingImages.reshape(-1, 28 * 28) / 255.0
    testingImages = testingImages.reshape(-1, 28 * 28) / 255.0
    trainingLabels = convertIntoFormat(trainingLabels, 10)
    testingLabels = convertIntoFormat(testingLabels, 10)

    return trainingImages, testingImages, trainingLabels, testingLabels

def convertIntoFormat(labels, size): # One hot encode values
    format = np.zeros((len(labels), size)) # Create list of zeros of same length as numbe of classes
    for i, label in enumerate(labels): 
        format[i][label] = 1    # insert a one where nessesary
    return format


def trainBestMNIST():

    LAYERS = [784,16,10]       
    maxAllowableOutput = 9e9
    epochs = 1
    lr = 0.01
    batchSize = 50
    seed = 100

    mlp = MLP(LAYERS,'relu',maxAllowableOutput,'he',seed,'cross')
    mlp.train(trainingImages,trainingLabels,epochs,lr,batchSize,testingImages,testingLabels,lrDecay=True,decayRate=0.9)
    return mlp


trainingImages, testingImages, trainingLabels, testingLabels = loadMNIST()
print("loaded")
answers = np.argmax(testingLabels, axis=1)
mlp = trainBestMNIST()
results = mlp.predict(testingImages)

mlp.save("saveFile.txt")
mlp.draw_structure()